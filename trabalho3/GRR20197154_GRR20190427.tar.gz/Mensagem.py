
class Mensagem():
    
    def __init__(self):
        self.marcador_inicio = 126  #01111110
        self.combinacao = 0
        self.saldo = 0
        self.jogador = 0
        self.dados = list()
        self.bastao = False
        self.paridade = 0
    
           
    